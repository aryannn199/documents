﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using A_3_9.Models;

namespace A_3_9.Controllers
{
    public class StudentController : Controller
    {
        Student s = new Student();
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=D:\\BHARAT_116\\AWT_NEW\\A_3_9\\A_3_9\\App_Data\\Database2.mdf;Integrated Security=True");
        
        // GET: Student
        public ActionResult Index()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Student_Details", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            List<Student> list = new List<Student>();
            for(int i=0; i < ds.Tables[0].Rows.Count; i++)
            {
                Student s = new Student();
                s.Id = int.Parse(ds.Tables[0].Rows[i]["Id"].ToString());
                s.Name = ds.Tables[0].Rows[i]["Name"].ToString();
                s.Percentage = ds.Tables[0].Rows[i]["Percentage"].ToString();
                list.Add(s);
            }
            return View(list);
        }

        // GET: Student/Details/5
        public ActionResult Details(int id)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Student_Details where Id="+id, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Student s = new Student();
            s.Id = int.Parse(ds.Tables[0].Rows[0]["Id"].ToString());
            s.Name = ds.Tables[0].Rows[0]["Name"].ToString();
            s.Percentage = ds.Tables[0].Rows[0]["Percentage"].ToString();
            return View(s);
        }

        // GET: Student/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Student/Create
        [HttpPost]
        public ActionResult Create(Student s)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Student_Details values('"+s.Name+"', "+s.Percentage+")", con);
                cmd.ExecuteNonQuery();
                con.Close();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Student/Edit/5
        public ActionResult Edit(int id)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Student_Details where Id=" + id, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Student s = new Student();
            s.Id = int.Parse(ds.Tables[0].Rows[0]["Id"].ToString());
            s.Name = ds.Tables[0].Rows[0]["Name"].ToString();
            s.Percentage = ds.Tables[0].Rows[0]["Percentage"].ToString();
            return View(s);
        }

        // POST: Student/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, Student s)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update Student_Details set Name='"+s.Name+"', Percentage="+s.Percentage+" where Id="+id, con);
                cmd.ExecuteNonQuery();
                con.Close();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Student/Delete/5
        public ActionResult Delete(int id)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Student_Details where Id=" + id, con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Student s = new Student();
            s.Id = int.Parse(ds.Tables[0].Rows[0]["Id"].ToString());
            s.Name = ds.Tables[0].Rows[0]["Name"].ToString();
            s.Percentage = ds.Tables[0].Rows[0]["Percentage"].ToString();
            return View(s);
        }

        // POST: Student/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Student s)
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from Student_Details where Id=" + id, con);
                cmd.ExecuteNonQuery();
                con.Close();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        localhost.WebService1 OBJ= new localhost.WebService1();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int RESULT = OBJ.InsertData
                (TextBox1.Text, int.Parse(TextBox2.Text));
            DataSet dataSet = new DataSet();
            dataSet = OBJ.SelectRecord();
            GridView1.DataSource = dataSet;
            GridView1.DataBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            DataSet dataSet = new DataSet();
            dataSet = OBJ.SearchRecord(TextBox1.Text);
            GridView1.DataSource = dataSet;
            GridView1.DataBind();
        }
    }
}
﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebApplication1
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        SqlConnection Con;



        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        public void connect()
        {
            Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Desktop\TIMSCDR\WebApplication1\WebApplication1\App_Data\Database1.mdf;Integrated Security=True");
            Con.Open();
        }
        [WebMethod]

        public int InsertData(String name, int price)
        {
            connect();
            SqlCommand cmd = new SqlCommand("Insert into Product_detail(name,price) values (' " + name + " '," + price + ")", Con);
            return cmd.ExecuteNonQuery();
        }

        [WebMethod]

        public DataSet SelectRecord()
        {
            connect();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Product_detail", Con);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds);
            return ds;
        }

        [WebMethod]

        public DataSet SearchRecord(string searchdata)
        {
            connect();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Product_detail where Name like '%" + searchdata + "%", Con);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds);
            return ds;
        }



    }
}

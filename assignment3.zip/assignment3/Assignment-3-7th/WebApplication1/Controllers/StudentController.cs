﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;


namespace WebApplication1.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        Student student = new Student();
        public ActionResult Index()
        {
            student.Id = 1;
            student.Name = "XYZ";
            student.Age = 38;
            return View(student);
        }
    }
}
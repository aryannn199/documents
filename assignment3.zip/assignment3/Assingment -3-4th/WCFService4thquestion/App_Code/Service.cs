﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    public void DoWork()
    {

    }
    SqlConnection con;
    public void connect()
    {
        con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename
=C:\Users\admin\Desktop\TIMSCDR\WCFService4thquestion\App_Data\Database.mdf
;Integrated Security=True");
        con.Open();
    }
    public int InsertData(string Name, int Price)
    {
        connect();
        SqlCommand cmd = new SqlCommand("insert into Product_detail (Name, Price) values ('" + Name
            +"'," + Price + ")", con);
        return cmd.ExecuteNonQuery();
      
    }

    public DataSet SearchRecord(string searrchdata)
    {
        connect();
        SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Product_detail where Name like '%" + searrchdata + "%'", con);
        DataSet ds = new DataSet();
        dataAdapter.Fill(ds);
        return ds;
    }

    public DataSet SelectRecord()
    {
        
        connect();
        SqlDataAdapter dataAdapter = new SqlDataAdapter("select * from Product_detail", con);
        DataSet ds = new DataSet();
        dataAdapter.Fill(ds);
        return ds;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mocule3_Practical1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {


        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            localhost.WebService1 webService1 = new localhost.WebService1();
            int res = webService1.Addition(int.Parse(TextBox1.Text), int.Parse(TextBox2.Text));
            Label1.Text=res.ToString();
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            localhost.WebService1 webService1 = new localhost.WebService1();
            int res = webService1.subtraction(int.Parse(TextBox1.Text), int.Parse(TextBox2.Text));
            Label1.Text = res.ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            localhost.WebService1 webService1 = new localhost.WebService1();
            int res = webService1.Multiplication(int.Parse(TextBox1.Text), int.Parse(TextBox2.Text));
            Label1.Text = res.ToString();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            localhost.WebService1 webService1 = new localhost.WebService1();
            int res = webService1.Division(int.Parse(TextBox1.Text), int.Parse(TextBox2.Text));
            Label1.Text = res.ToString();
        }
    }
}
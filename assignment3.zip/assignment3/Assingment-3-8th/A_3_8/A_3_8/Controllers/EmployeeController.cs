﻿using A_3_8.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace A_3_8.Controllers
{
    public class EmployeeController : Controller
    {
        Employee emp = new Employee();
        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Show_Emp()
        {
            emp.Id = Int32.Parse(Request.Form["empid"].ToString());
            emp.Name = Request.Form["name"].ToString();
            emp.Salary = Int32.Parse(Request.Form["salary"].ToString());
            return View(emp);
        }
    }
}
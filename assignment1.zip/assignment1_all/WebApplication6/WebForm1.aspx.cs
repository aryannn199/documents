﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                String filename = Path.GetFileName(FileUpload1.FileName);
                String ext  = Path.GetExtension(FileUpload1.FileName);
                if (ext.ToLower() == ".jpg")
                {
                    FileUpload1.SaveAs(Server.MapPath("~/img/")+filename);
                    Label1.Text = "File Uploaded";
                    Image1.ImageUrl = "~/img/" + filename;
                }
                if (ext.ToLower() == ".png")
                {
                    FileUpload1.SaveAs(Server.MapPath("~/img/") + filename);
                    Label1.Text = "File Uploaded";
                    Image1.ImageUrl = "~/img/" + filename;
                }
                if (ext.ToLower() == ".jpeg")
                {
                    FileUpload1.SaveAs(Server.MapPath("~/img/") + filename);
                    Label1.Text = "File Uploaded";
                    Image1.ImageUrl = "~/img/" + filename;
                }
            }
        }
    }
}
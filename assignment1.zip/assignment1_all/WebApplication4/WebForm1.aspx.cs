﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string breakfast = "";
            string time = "";
            if (CheckBox1.Checked)
            {
                breakfast = breakfast + CheckBox1.Text +", ";
            }
            if (CheckBox2.Checked)
            {
                breakfast = breakfast + CheckBox2.Text + ", ";
            }
            if (CheckBox3.Checked)
            {
                breakfast = breakfast + CheckBox3.Text + ", ";
            }


            if(RadioButton1.Checked)
            {
                time = time + RadioButton1.Text;
            }
            else if (RadioButton2.Checked)
            {
                time = time + RadioButton2.Text;
            }

            Label4.Text = "Thank you very much "+TextBox1.Text+" . "+"\n You have chosen "+breakfast.Trim(',', ' ')+" for breakfast. I will prepare it for you "+time+" .";
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication20
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl1.SelectedItem.Text == "Maharashtra")
            {
                ddl2.Items.Clear();
                ddl2.Items.Add("mumbai");
                ddl2.Items.Add("pune");
                ddl2.Items.Add("nashik");
            }
            else if (ddl1.SelectedItem.Text == "Gujarat")
            {
                ddl2.Items.Clear();
                ddl2.Items.Add("surat");
                ddl2.Items.Add("vadodra");
                ddl2.Items.Add("ahemdabad");
            }
            else if (ddl1.SelectedItem.Text == "Rajasthan")
            {
                ddl2.Items.Clear();
                ddl2.Items.Add("jaipur");
                ddl2.Items.Add("jaisalmer");
                ddl2.Items.Add("jodhpur");
            }
            else if (ddl1.SelectedItem.Text == "UP")
            {
                ddl2.Items.Clear();
                ddl2.Items.Add("banaras");
                ddl2.Items.Add("prayagraj");
                ddl2.Items.Add("ayodhya");
            }
        }
    }
}
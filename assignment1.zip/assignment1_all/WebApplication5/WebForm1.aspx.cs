﻿using System;
using System.Web.UI.WebControls;

namespace WebApplication5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize items in DropDownList2 when the page loads for the first time, if needed.
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clear existing items in DropDownList2
            DropDownList2.Items.Clear();

            // Add new items to DropDownList2 based on the selected state
            if (DropDownList1.SelectedItem.Text == "Maharashtra")
            {
                DropDownList2.Items.Add("Mumbai");
                DropDownList2.Items.Add("Pune");
                DropDownList2.Items.Add("Thane");
            }
            else if (DropDownList1.SelectedItem.Text == "Uttar Pradesh")
            {
                DropDownList2.Items.Add("Varanasi");
                DropDownList2.Items.Add("Prayagraj");
                DropDownList2.Items.Add("Ayodhaya");
            }
            else if (DropDownList1.SelectedItem.Text == "Rajasthan")
            {
                DropDownList2.Items.Add("Jaipur");
                DropDownList2.Items.Add("Jaisalmer");
                DropDownList2.Items.Add("Bikaner");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication16
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["fname"]!=null && Session["lname"] != null)
            {
                String fname = Session["fname"].ToString();
                String lname = Session["lname"].ToString();

                Response.Write("Name is: " + fname + " Surname is: " + lname);
            }
            else
            {
                Response.Redirect("WebForm1.aspx");
            }
        }
    }
}
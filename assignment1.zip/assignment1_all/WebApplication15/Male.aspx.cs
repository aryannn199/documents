﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication15
{
    public partial class Male : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int weight = 0;
            String name = Request.Cookies["data"].Values["name"];
            String age = Request.Cookies["data"].Values["age"];
            String height = Request.Cookies["data"].Values["height"];
            String email = Request.Cookies["data"].Values["email"];

            if (int.Parse(height) == 150)
            {
                weight = 60;
            }
            if (int.Parse(height) == 160)
            {
                weight = 65;
            }
            if (int.Parse(height) == 170)
            {
                weight = 70;
            }
            if (int.Parse(height) == 180)
            {
                weight = 75;
            }
            if (int.Parse(height) == 190)
            {
                weight = 80;
            }

            Response.Write("Name: "+name+"\n Age: "+age+"\n Height: "+height+"\n Email: "+email+"\n Ideal Weight: "+weight);
        }
    }
}
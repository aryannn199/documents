﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication15
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HttpCookie cookie = new HttpCookie("data");
            cookie.Values["name"] = TextBox1.Text;
            cookie.Values["age"] = TextBox2.Text;
            cookie.Values["height"] = TextBox3.Text;
            cookie.Values["email"] = TextBox4.Text;

            string gender = "";
            if(RadioButton1.Checked)
            {
                gender = "Male";
            }
            if (RadioButton2.Checked)
            {
                gender = "Female";
            }

            cookie.Values["gender"]=gender;

            Response.Cookies.Add(cookie);

            if(gender == "Male")
            {
                Response.Redirect("Male.aspx");
            }
            else
            {
                Response.Redirect("Female.aspx");
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication19
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        static int i = 0;

        protected void Timer1_Tick(object sender, EventArgs e)
        {
            if (i == 0)
            {
                img1.ImageUrl = "~/img/i1.jpg";
                i = 1;
            }
            else if (i == 1)
            {
                img1.ImageUrl = "~/img/i2.jpg";
                i = 2;
            }
            else
            {
                img1.ImageUrl = "~/img/i3.jpg";
                i = 0;
            }
        }
    }
}
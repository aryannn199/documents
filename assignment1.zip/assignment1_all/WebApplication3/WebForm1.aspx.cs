﻿using System;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label3.Font.Name = DropDownList1.SelectedItem.Text;
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Label3.Font.Size = Convert.ToInt32(DropDownList2.SelectedItem.Text.Replace("px", ""));
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            Label3.Font.Bold = CheckBox1.Checked;
        }

        protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            Label3.Font.Italic = CheckBox2.Checked;
        }

        protected void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
            Label3.Font.Underline = CheckBox3.Checked;
        }
    }
}

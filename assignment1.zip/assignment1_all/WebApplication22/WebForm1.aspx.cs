﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication22
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String cachedData = (String)Cache["CacheData"];

            if(cachedData == null)
            {
                cachedData = GetDataFromDatabase();
                Cache.Insert("cacheData", cachedData, null, DateTime.Now.AddSeconds(10), TimeSpan.Zero);
            }
            Label1.Text = cachedData;
        }

        private String GetDataFromDatabase()
        {
            return "Data retrieved at : " + DateTime.Now.ToString("HH:mm:ss");
        }
    }
}